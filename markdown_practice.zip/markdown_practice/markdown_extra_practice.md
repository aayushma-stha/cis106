#### Document 1:

# What is Linux?

Looking to get started in Linux? Develop a good working knowledge of Linux using both the graphical interface and command line across the major Linux distribution families with The Linux Foundation’s _[Intro to Linux](https://training.linuxfoundation.org/training/introduction-to-linux/?utm_source=linuxcom&utm_medium=blog&utm_campaign=lfs101&__hstc=229720963.974e31c8e1680712b4cac09aa1c18b61.1757779788570.1758290596577.1758306661981.3&__hssc=229720963.2.1758306661981&__hsfp=3967631246)_ online course. Enroll for free _[here](https://training.linuxfoundation.org/training/introduction-to-linux/?utm_source=linuxcom&utm_medium=blog&utm_campaign=lfs101&__hstc=229720963.974e31c8e1680712b4cac09aa1c18b61.1757779788570.1758290596577.1758306661981.3&__hssc=229720963.2.1758306661981&__hsfp=3967631246)_. (Este curso también está disponible en español. _[Haga clic aquí para Introducción a Linux](https://training.linuxfoundation.org/training/introduccion-a-linux-lf-upv-101x/?__hstc=229720963.974e31c8e1680712b4cac09aa1c18b61.1757779788570.1758290596577.1758306661981.3&__hssc=229720963.2.1758306661981&__hsfp=3967631246)_.)

![The Linux mascot](https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Tux.svg/330px-Tux.svg.png)

### What is Linux?

Just like Windows, iOS, and Mac OS, Linux is an operating system. In fact, one of the most popular platforms on the planet, Android, is powered by the Linux operating system. An operating system is software that manages all of the hardware resources associated with your desktop or laptop. To put it simply, the operating system manages the communication between your software and your hardware. Without the operating system (OS), the software wouldn’t function.

The Linux operating system comprises several different pieces:

1. **Bootloader** – The software that manages the boot process of your computer. For most users, this will simply be a splash screen that pops up and eventually goes away to boot into the operating system.
2. **Kernel** – This is the one piece of the whole that is actually called ‘Linux’. The kernel is the core of the system and manages the CPU, memory, and peripheral devices. The kernel is the lowest level of the OS.
3. **Init system** – This is a sub-system that bootstraps the user space and is charged with controlling daemons. One of the most widely used init systems is systemd, which also happens to be one of the most controversial. It is the init system that manages the boot process, once the initial booting is handed over from the bootloader (i.e., GRUB or GRand Unified Bootloader).
4. **Daemons** – These are background services (printing, sound, scheduling, etc.) that either start up during boot or after you log into the desktop.

### Open source

Linux is also distributed under an open source license. Open source follows these key tenets:

- The freedom to run the program, for any purpose.
- The freedom to study how the program works, and change it to make it do what you wish.
- The freedom to redistribute copies so you can help your neighbor.
- The freedom to distribute copies of your modified versions to others.

### What is a “distribution?”

Linux has a number of different versions to suit any type of user. From new users to hard-core users, you’ll find a “flavor” of Linux to match your needs. These versions are called distributions (or, in the short form, “distros”). Nearly every distribution of Linux can be downloaded for free, burned onto disk (or USB thumb drive), and installed (on as many machines as you like).

Popular Linux distributions include:

| S.N | Name          | Logos                                                 |
| --- | ------------- | ----------------------------------------------------- |
| 1   | Arch Linux    | ![Arch Linux](Icons8/icons8-arch-linux-100.png)       |
| 2   | CentOS        | ![CentOS](Icons8/icons8-centos-100.png)               |
| 3   | Debian        | ![Debian](Icons8/icons8-debian-100.png)               |
| 4   | Fedora        | ![Fedora](Icons8/icons8-fedora-100.png)               |
| 5   | Kali Linux    | ![Kali Linux](Icons8/icons8-kali-linux-100.png)       |
| 6   | Ubuntu Studio | ![Ubuntu Studio](Icons8/icons8-ubuntu-studio-100.png) |

---

#### Document 2:

# Welcome

Welcome to the LearnPython.org interactive Python tutorial. This website is proudly supported by [Boot.dev's Learn Python course](https://www.boot.dev/courses/learn-code-python?promo=LEARNXORG). If you'd like to learn Python from start to finish, [become a member and use code LEARNXORG](https://www.boot.dev/pricing?promo=LEARNXORG) for 25% off your first year!

Whether you are an experienced programmer or not, this website is intended for everyone who wishes to learn the Python programming language.

You are welcome to join our group on [Facebook](https://www.facebook.com/groups/180708015327157/) for questions, discussions and updates.

After you complete the tutorials, you can get certified at [LearnX](https://www.learnx.org/) and add your certification to your LinkedIn profile.

Just click on the chapter you wish to begin from, and follow the instructions. Good luck!

### Learn the Basics

- [Hello, World!](https://www.learnpython.org/en/Hello%2C_World%21)
  ```python
  print("Hello World.")
  ```
- [Variables and Types](https://www.learnpython.org/en/Variables_and_Types)
  ```python
  age = 7
  print(age)
  ```
- [Lists](https://www.learnpython.org/en/Lists)

  ```python
  mylist = []
  mylist.append(1)
  mylist.append(2)
  mylist.append(3)
  print(mylist[0]) # prints 1
  print(mylist[1]) # prints 2
  print(mylist[2]) # prints 3
  # prints out 1,2,3
  for x in mylist:
      print(x)
  ```
- [Basic Operators](https://www.learnpython.org/en/Basic_Operators)
  ```python
  number = 1 + 2 * 3 / 4.0
  print(number)
  ```
- [String Formatting](https://www.learnpython.org/en/String_Formatting)
  ```python
  # This prints out "Hello, John!"
  name = "John"
  print("Hello, %s!" % name)
  ```
- [Basic String Operations](https://www.learnpython.org/en/Basic_String_Operations)
  ```python
  astring = "Hello world!"
  astring2 = 'Hello world!'
  ```
- [Conditions](https://www.learnpython.org/en/Conditions)
  ```python
  x = 2
  print(x == 2) # prints out True
  print(x == 3) # prints out False
  print(x < 3) # prints out True
  ```
- [Loops](https://www.learnpython.org/en/Loops)
  ```python
  primes = [2, 3, 5, 7]
  for prime in primes:
      print(prime)    
  ```
---

#### Document 3:

### Table 1

| Id  | Name            | Email                   | Investments          |
| --- | --------------- | ----------------------- | -------------------- |
| 231 | Albert Master   | albert.master@gmail.com | Bonds                |
| 210 | Alfred Alan     | aalan@gmail.com         | Stocks               |
| 256 | Alison Smart    | asmart@biztalk.com      | Residential Property |
| 211 | Ally Emery      | allye@easymail.com      | Stocks               |
| 248 | Andrew Phips    | andyp@mycorp.com        | Stocks               |
| 234 | Andy Mitchel    | andym@hotmail.com       | Stocks               |
| 226 | Angus Robins    | arobins@robins.com      | Bonds                |
| 241 | Ann Melan       | ann_melan@iinet.com     | Residential Property |
| 225 | Ben Bessel      | benb@hotmail.com        | Stocks               |
| 235 | Bensen Romanolf | benr@albert.net         | Bonds                |

### Grade Distribution

| Letter Grade | Percentage |
| ------------ | ---------- |
| A            | 90 - 100%  |
| B            | 80-89.99%  |
| C            | 70-79.99%  |
| D            | 60-69.99%  |
| F            | <60%       |

<br>

| Part  | name          |
| ----- | ------------- |
| ![Graphics Card](computer_parts_png/gpu.png) | Graphics Card |
| ![Hard Drive](computer_parts_png/hard-disk.png) | Hard Drive    |
| ![Motherboard](./computer_parts_png/motherboard.png) | Motherboard   |
| ![RAM](./computer_parts_png/ram.png) | RAM           |
