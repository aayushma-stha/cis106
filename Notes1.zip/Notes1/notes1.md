# Notes 1

## What is Markdown?
Markdown is a markup language that lets us write plain text documents with a few lightweight formatting options createed in 2004 by John Gruber. 

## What is Git?
Git is the most widely used modern distributed version control system in the world today. It is a mature, actively maintained open source project originally developed in 2005 by Linus Torvalds, the famous creator of the Linux operating system kernel.

## What is GitHub?
GitHub is the cloud-based version control system for hosting Git repositories for collaborations with other developers to store, share, and work together to write code.

## What is Slack?
 Slack is a instant messaging program designed by Slack Technologies for team communication that allows users to chat, share files, and integrate with other software and owned by Salesforce.
 